document.addEventListener("DOMContentLoaded", async () => {
	const patientDetails = document.getElementById("patientDetails");

	const urlParams = new URLSearchParams(window.location.search);
	const ohipNumber = urlParams.get("ohip");

	try {
		const response = await fetch(`http://192.168.222.149:3000/api5/patient-record?ohip=${ohipNumber}`);
		if (response.ok) {
			const data = await response.json();
		//Display patient data on the page
			patientDetails.innerHTML = JSON.stringify(data, null, 2);
		} else {
			patientDetails.textContent = "Error fetching patient record.";
		}
	} catch (error) {
		console.error("An error occurred while fetching patient record:", error);
		patientDetails.textContent = "An error occurred while fetching patient record.";
	}
});
