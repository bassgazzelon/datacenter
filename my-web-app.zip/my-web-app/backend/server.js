const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt');
const mysql = require('mysql2/promise');
const app =express();
const cors = require('cors');
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use (
	session({
		secret: 'Pa$$w0rd',
		resave: false,
		saveUninitialized: true,
	})
);

app.use(cors()); 

const pool = mysql.createPool({
	host: '192.168.222.151',
	user: 'group3',
	password: 'Pa$$w0rd',
	database: 'clinic_app',
});

app.use('/api', require('./routes/auth'));
app.use('/api2', require('./routes/chpass'));
app.use('/api3', require('./routes/create-patient'));
app.use('/api4', require('./routes/search-patient'));
app.use('/api5', require('./routes/patient-record'));

app.listen(PORT, () => {
	console.log(`Server is running on port ${PORT}`);
});
