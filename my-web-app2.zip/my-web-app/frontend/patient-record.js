document.addEventListener("DOMContentLoaded", async () => {
	const patientDetails = document.getElementById("patientDetails");

	const urlParams = new URLSearchParams(window.location.search);
	const ohipNumber = urlParams.get("ohip");

	try {
		const response = await fetch(`http://192.168.222.149:3000/api5/patient-record?ohip=${ohipNumber}`);
		if (response.ok) {
			const data = await response.json();
		
			displayPatientDetails(patientDetails, data);

			editButton.addEventListener("click", () => {
				window.location.href = `edit-patient.html?ohip=${ohipNumber}`;
			});	
		} else {
			patientDetails.textContent = "Error fetching patient record.";
		}
	} catch (error) {
		console.error("An error occurred while fetching patient record:", error);
		patientDetails.textContent = "An error occurred while fetching patient record.";
	}
});

function displayPatientDetails(container, data) {
	const patientDetailsHTML = `
		<div class="patient-details">
			<p><strong>Name:</strong> ${data.FirstName} ${data.LastName}</p>
			<p><strong>Gender:</strong> ${data.Gender}</p>
			<p><strong>Date of Birth:</strong> ${new Date(data.DateOfBirth).toLocaleDateString()}</p>
			<p><strong>Contact Number:</strong> ${data.ContactNumber}</p>
			<p><strong>Emergency Contact:</strong> ${data.EmergencyContactName} - ${data.EmergencyContactNumber}</p>
			<p><strong>Weight:</strong> ${data.Weight} kg</p>
			<p><strong>Height:</strong> ${data.Height} cm</p>
			<p><strong>Blood Type:</strong> ${data.BloodType}</p>
			<p><strong>Allergies:</strong> ${data.Allergies}</p>
			<p><strong>Medical History:</strong> ${data.MedicalHistory}</p>
			<p><strong>Current Symptoms:</strong> ${data.CurrentSymptoms}</p>
			<p><strong>Last Updated:</strong> ${new Date(data.LastUpdated).toLocaleString()}</p>
		</div>
	`;
	container.innerHTML = patientDetailsHTML;
}

