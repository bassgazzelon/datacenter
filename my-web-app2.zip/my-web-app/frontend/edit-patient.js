document.addEventListener("DOMContentLoaded", async () => {
	const editPatientForm = document.getElementById("editPatientForm");
	const saveButton = document.getElementById("saveButton");

	const urlParams = new URLSearchParams(window.location.search);
	const ohipNumber = urlParams.get("ohip");

	try {
		const response = await fetch(`http://192.168.222.149:3000/api5/patient-record?ohip=${ohipNumber}`);
		if (response.ok) {
			const data = await response.json();

			renderEditForm(editPatientForm, data);
		} else {
			editPatientForm.textContent = "Error fetching patient record.";
		}
	} catch (error) {
		console.error("An error occurred while fetching patient record:", error);
		editPatientForm.textContent = "An error occurred while fetching patient record.";
	}


	saveButton.addEventListener("click", async () => {

		const updatedData = collectUpdatedData();

		try {

			const response = await fetch('http://192.168.222.149:3000/api6/save-patient', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ ohip: ohipNumber, updatedData }),
			});

			if (response.ok) {
				const result = await response.json();
				alert(result.message); 

				window.location.href = `patient-record.html?ohip=${ohipNumber}`;
			} else {
				console.error("Error saving patient record:", response.status);
			}
		} catch (error) {
			console.error("An error occurred while saving patient record:", error);

		}
	});
});


function renderEditForm(container, data) {
	const formattedDateOfBirth = new Date(data.DateOfBirth).toISOString().split('T')[0];

	container.innerHTML = `
		<form id="editForm">
			<label for="firstName">First Name:</label>
			<input type="text" id="firstName" value="${data.FirstName}">

			<label for="lastName">Last Name:</label>
			<input type="text" id="lastName" value="${data.LastName}">

			<label for="gender">Gender:</label>
			<input type="text" id="gender" value="${data.Gender}">

			<label for="dateOfBirth">Date of Birth:</label>
			<input type="date" id="dateOfBirth" value="${formattedDateOfBirth}">

			<label for="contactNumber">Contact Number:</label>
			<input type="tel" id="contactNumber" value="${data.ContactNumber}">

			<label for="emergencyContactName">Emergency Contact Name:</label>
			<input type="text" id="emergencyContactName" value="${data.EmergencyContactName}">
	
			<label for="emergencyContactNumber">Emergency Contact Number:</label>
			<input type="tel" id="emergencyContactNumber" value="${data.EmergencyContactNumber}">

			<label for="weight">Weight (kg):</label>
			<input type="number" id="weight" value="${data.Weight}">

			<label for="height">Height (kg):</label>
			<input type="number" id="height" value="${data.Height}">

			<label for="bloodType">Blood Type:</label>
			<input type="text" id="bloodType" value="${data.BloodType}">

			<label for="allergies">Allergies:</label>
			<input type="text" id="allergies" value="${data.Allergies}">

			<label for="medicalHistory">Medical History:</label>
	                <textarea id="medicalHistory">${data.MedicalHistory}</textarea>

			<label for="currentSymptoms">Current Symptoms:</label>
			<textarea id="currentSymptoms">${data.CurrentSymptoms}</textarea>

		</form>

	`;
}


function collectUpdatedData() {

	const firstName = document.getElementById("firstName").value;
	const lastName = document.getElementById("lastName").value;
	const gender = document.getElementById("gender").value;
	const dateOfBirth = document.getElementById("dateOfBirth").value;
	const contactNumber = document.getElementById('contactNumber').value;
	const emergencyContactName = document.getElementById('emergencyContactName').value;
	const emergencyContactNumber = document.getElementById('emergencyContactNumber').value;
	const weight = document.getElementById('weight').value;
	const height = document.getElementById('height').value;
	const bloodType = document.getElementById('bloodType').value;
	const allergies = document.getElementById('allergies').value;
	const medicalHistory = document.getElementById('medicalHistory').value;
	const currentSymptoms = document.getElementById('currentSymptoms').value;

	return {
		FirstName: firstName,
		LastName: lastName,
		Gender: gender,
		DateOfBirth: dateOfBirth,
		ContactNumber: contactNumber,
		EmergencyContactName: emergencyContactName,
		EmergencyContactNumber: emergencyContactNumber,
		Weight: weight,
		Height: height,
		BloodType: bloodType,
		Allergies: allergies,
		MedicalHistory: medicalHistory,
		CurrentSymptoms: currentSymptoms,

	};
}

