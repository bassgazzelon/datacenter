const express = require('express');
const bcrypt = require('bcrypt');
const router = express.Router();
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
	host: '192.168.222.151',
	user: 'group3',
	password: 'Pa$$w0rd',
	database: 'clinic_app',
});


const isAuthenticated = async (username, oldPassword) => {
	const [rows] = await pool.query('SELECT hashed_password FROM users WHERE username = ?', [username]);

	if (rows.length === 1) {
		const hashedPassword = rows[0].hashed_password;
		return bcrypt.compare(oldPassword, hashedPassword);
	} else {
		return false;
	}
};

router.post('/change-password', async (req, res) => {
	const { username, oldPassword, newPassword } = req.body;


	const isAuth = await isAuthenticated(username, oldPassword);

	if (!isAuth) {
		res.status(401).json({ message: 'Incorrect old password' });
		return;
	}


	const hashedPassword = await bcrypt.hash(newPassword, 10);

	try {
		const [result] = await pool.query('UPDATE users SET hashed_password = ? WHERE username = ?', [
			hashedPassword,
			username,
		]);

		if (result.affectedRows === 1) {
			res.json({ message: 'Password updated successfully' });
		} else {
			res.status(500).json({ message: 'Failed to update password' });
		}
	} catch (error) {
		console.error('Error updating password:', error);
		res.status(500).json({ message: 'Internal server error' });
	}
});

module.exports = router;

