const express = require('express');
const bcrypt = require('bcrypt');
const router = express.Router();
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
	host: '192.168.222.151',
	user: 'group3',
	password: 'Pa$$w0rd',
	database: 'clinic_app',
});

router.post('/login', async (req, res) => {
	const { username, password } = req.body;
	const [rows] = await pool.query('SELECT * FROM users WHERE username = ?', [username]);

	if (rows.length === 1) {
		const hashedPassword = rows[0].hashed_password;


		const passwordMatch = await bcrypt.compare(password, hashedPassword);

		if (passwordMatch) {
			req.session.user = username;
			res.json({ message: 'Login successful', role: rows[0].role });
		} else {
			res.status(401).json({ message: 'Invalid username or password' });
		}
	} else {
		res.status(401).json({ message: 'Invalid username or password' });
	}
});

router.get('/logout', (req, res) => {
	req.session.destroy();
	res.json({ message: 'Logged out' });
});

module.exports = router;

