const express = require('express');
const router = express.Router();
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
	host: '192.168.222.151',
	user: 'group3',
	password: 'Pa$$w0rd',
	database: 'clinic_app',
});

router.post('/create-patient', async (req, res) => {
	const {
		OHIP,
		firstName,
		lastName,
		gender,
		dateOfBirth,
		contactNumber,
		emergencyContactName,
		emergencyContactNumber,
		weight,
		height,
		bloodType,
		allergies,
		medicalHistory,
		currentSymptoms,
	} = req.body;

	try {
		console.log('Received request with body:', req.body);

		const connection = await pool.getConnection();
		console.log('Connected to the database');

		const insertQuery = `
		INSERT INTO Patients (
		OHIP, FirstName, LastName, Gender, DateOfBirth, ContactNumber, 
		EmergencyContactName, EmergencyContactNumber, Weight, Height, 
		BloodType, Allergies, MedicalHistory, CurrentSymptoms
		) 
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
		`;

		const [result] = await connection.query(insertQuery, [
			OHIP,
			firstName,
			lastName,
			gender,
			dateOfBirth,
			contactNumber,
			emergencyContactName,
			emergencyContactNumber,
			weight,
			height,
			bloodType,
			allergies,
			medicalHistory,
			currentSymptoms,
		]);

		connection.release();

		if (result.affectedRows === 1) {
			res.status(201).json({ message: 'Patient record created successfully' });
		} else {
			res.status(500).json({ message: 'Failed to create patient record' });
		}
	} catch (error) {
		console.error('Error creating patient record:', error);
		res.status(500).json({ message: 'Failed to create patient record', error: error.message });
	}
});

module.exports = router;

