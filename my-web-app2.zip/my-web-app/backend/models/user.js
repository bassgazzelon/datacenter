const mysql = require('mysql2/promise');

const pool = mysql.createPool({
		host: '192.168.222.151',
		user: 'group3',
		password: 'Pa$$w0rd',
		database: 'clinic_app',
});

module.exports = pool;
